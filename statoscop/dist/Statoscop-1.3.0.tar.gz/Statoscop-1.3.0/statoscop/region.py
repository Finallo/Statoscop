def region():
    """
    This function return all regions available.
    :return: a dataframe.
    """
    return "Available regions are : \n All, north-america, europe, brazil, asia-pacific, korea, japan, latin-america, oceania, mena, game-changers, collegiate"